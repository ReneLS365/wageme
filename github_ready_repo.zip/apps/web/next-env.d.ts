/// <reference types="next" />
/// <reference types="next/image-types/global" />
/// <reference types="next/navigation-types/compat" />

// Dette er en automatisk genereret declarationsfil påkrævet af Next.js. Må ikke slettes eller redigeres.
